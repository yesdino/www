<!-- <!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title></title>

<link rel="stylesheet" href="style.css">
</head>
<link rel="stylesheet" type="text/css" href="lib/bootstrap-3.3.7/dist/css/bootstrap.min.css"> -->
<style type="text/css">
#Footer{
	width: 65%;    background-color: #E8EDED;
	margin:0 auto 30px;
	text-align: center;
	font-size: 12px;
	color: #45565A;
	padding-top: 8px;
}
</style>

<!-- <body> -->
<div id="Footer">
Copyright © Guangdong Ocean University MeiXian association 2017 All Rights Reserved</br>
版权所有：广东海洋大学梅县同乡会</br>
地址：中华人民共和国 广东省 湛江市 麻章区 海大路1号</br>　
</div>


<!-- </body>
</html> -->