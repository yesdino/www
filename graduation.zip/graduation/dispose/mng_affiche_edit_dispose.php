<?php
require_once("mysql_connect.php");  

$title = $_POST['txt_title']; 
$content = $_POST['txt_content']; 
$id = $_GET['id']; 
$page2 = $_GET['page'];

// $sql = mysql_query("update affiche set title='$title',long_content='$content' where id=$id");    
$query = "update affiche set title='$title',long_content='$content' where id=$id";
$sql = $pdo->prepare($query);
$sql->execute();

if($sql)
{
	echo "<script>
		alert('修改成功');
		window.location.href = '../manager.php?page=$page2';
	</script>";
}
else
{
	echo "<script>alert('修改失败！');history.back();</script> ";
}
// mysql_close($con);
?>